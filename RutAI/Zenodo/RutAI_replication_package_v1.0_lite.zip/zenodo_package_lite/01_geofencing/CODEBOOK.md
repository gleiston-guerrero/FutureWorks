# Geofencing dataset — Codebook

This folder contains raw and derived data for the geofence accuracy experiment reported in Section 5.1 of the paper.

## Files

| File | Description |
|------|-------------|
| `geofence_triggers_raw.xlsx` | Raw trigger log (139 events). Each row is one trigger event reported by RutAI during a session. Used to verify the data preparation pipeline. |
| `geofence_triggers_collapsed_n78.csv` | **Analysis dataset (n = 78 independent observations).** One row per (POI × radius × session) tuple, after collapsing temporally correlated triggers. This is the dataset used for all metrics reported in the paper. |
| `geofence_summary_by_radius.csv` / `.xlsx` | Pre-aggregated metrics by radius (legacy, generated from raw triggers; superseded by the collapsed dataset for reporting). |
| `calculate_geofence_metrics.py` | Analysis script (v2) that reads the trigger log, applies the collapsing rule, and computes Wilson 95% CIs for precision and recall. |
| `track_2026-05-01_session1.gpx` | GPX track for field session 1 (2026-05-01, 194 trackpoints). Ground-truth trajectory used to label TP/FP/TN/FN. |
| `track_2026-05-03_session2.gpx` | GPX track for field session 2 (2026-05-03, 1111 trackpoints). |

## Variables in `geofence_triggers_raw.xlsx` (sheet "Geofence Triggers")

| Column | Type | Description |
|--------|------|-------------|
| `#` | int | Sequential trigger ID |
| `Punto` | str | Point of interest name (20 unique values) |
| `Radio (m)` | int | Geofence radius: 50, 100, or 200 |
| `Modo` | str | Speed mode label assigned by experimenter |
| `GPS_lat (disparo)` | float | GPS latitude at trigger time (WGS84) |
| `GPS_lon (disparo)` | float | GPS longitude at trigger time (WGS84) |
| `App Disparó` | "Sí"/"No" | Whether the application fired a trigger event |
| `Dist GPS-Centro (m)` | float | Reported distance from trigger position to centroid (haversine; 9 rows with > 20 m discrepancy vs. recomputed haversine, see paper §6.5) |
| `Tiempo Disparo (ECU)` | time | Local time at trigger (Ecuador time, UTC−5) |
| `Ground Truth` | "Sí"/"No" | Manually-assigned label: was the experimenter inside the geofence? |
| `TP/FP/FN` | str | Classification: TP, FP, TN, or FN |
| `Vel (m/s)` | float | Speed at trigger time, derived from GPX track |
| `Prec_GPS (m)` | float | GPS-reported accuracy at trigger time |
| `Recorrido #` | int | Session number: 1, 2, or 3 |
| `Observaciones` | str | Free-text notes from experimenter |
| `Estado` | str | Visit status flag |
| `Lat_centro` | float | Latitude of geofence centroid (WGS84) |
| `Lon_centro` | float | Longitude of geofence centroid (WGS84) |

## Variables in `geofence_triggers_collapsed_n78.csv` (analysis dataset)

| Column | Type | Description |
|--------|------|-------------|
| `punto` | str | Point of interest name |
| `radio_m` | int | Geofence radius (50, 100, 200) |
| `recorrido` | int | Field session (1, 2, 3) |
| `modo` | str | Speed mode label |
| `n_raw_triggers` | int | Number of raw triggers collapsed into this observation |
| `label` | str | Final classification: TP, FP, TN, FN (dominant label across raw triggers in the tuple) |
| `app_disparo_alguna` | bool | Did the application fire at least once during this tuple? |
| `dist_min_centro_m` | float | Minimum reported distance to centroid across raw triggers |
| `dist_max_centro_m` | float | Maximum reported distance to centroid |
| `vel_mean_ms` | float | Mean speed during the tuple (m/s) |
| `prec_gps_mean_m` | float | Mean reported GPS accuracy during the tuple (m) |
| `lat_centro` / `lon_centro` | float | Centroid coordinates (WGS84) |

## Reproducing the metrics

```python
import pandas as pd
import numpy as np

df = pd.read_csv("geofence_triggers_collapsed_n78.csv")

def wilson_ci(k, n, z=1.96):
    if n == 0: return (0.0, 0.0)
    p = k/n
    denom = 1 + z*z/n
    centre = (p + z*z/(2*n)) / denom
    margin = z * np.sqrt(p*(1-p)/n + z*z/(4*n*n)) / denom
    return (max(0, centre-margin), min(1, centre+margin))

for r in [50, 100, 200]:
    sub = df[df.radio_m == r]
    tp = (sub.label == "TP").sum()
    fp = (sub.label == "FP").sum()
    fn = (sub.label == "FN").sum()
    tn = (sub.label == "TN").sum()
    prec = tp / (tp + fp) if (tp + fp) else 0
    rec  = tp / (tp + fn) if (tp + fn) else 0
    f1   = 2 * prec * rec / (prec + rec) if (prec + rec) else 0
    print(f"R={r}m  TP={tp} FP={fp} FN={fn} TN={tn}  "
          f"P={prec:.3f} {wilson_ci(tp, tp+fp)}  "
          f"R={rec:.3f}  F1={f1:.3f}")
```

Expected output (Table 1 in the paper):

```
R=50m   TP=18 FP=4 FN=0 TN=6   P=0.818 (0.615, 0.927)  R=1.000  F1=0.900
R=100m  TP=20 FP=3 FN=0 TN=7   P=0.870 (0.679, 0.955)  R=1.000  F1=0.930
R=200m  TP=20 FP=0 FN=0 TN=0   P=1.000 (0.839, 1.000)  R=1.000  F1=1.000
```

## Known limitations of this dataset

1. **Ground-truth source documentation:** the `Fuentes_GT` field in the legacy summary CSV reads `no_documentada`. Ground-truth labels were assigned post-hoc by the experimenter using the GPX track and centroid coordinate; while every distance was verified against haversine recomputation, the labeling procedure is not formally certified by an independent source. See paper §6.5.

2. **Distance field discrepancies:** 9 rows in the raw trigger log show ≥ 20 m discrepancy between the recorded `Dist GPS-Centro` field and the haversine recomputation from the recorded coordinates against the centroid. For analysis we use the haversine-recomputed value.

3. **Mode labeling:** all 139 raw triggers are labeled `Vehicular`, but only 75 (54%) fall in the declared vehicular speed range (≥ 8.3 m/s). The collapsed dataset preserves `vel_mean_ms` so users can re-stratify by effective speed.

4. **Single-experimenter, single-city:** all data was collected by one person in Quevedo, Ecuador, in May 2026.
