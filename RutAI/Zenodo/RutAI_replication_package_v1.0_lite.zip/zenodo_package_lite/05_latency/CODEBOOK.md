# Latency under load — Codebook

This folder contains backend latency measurements reported in Section 5.4.2 of the paper.

## Files

| File | Description |
|------|-------------|
| `load_test_k6.js` | k6 load-test script. Set `NIVEL_CARGA` to 10, 50, or 100 and run. |
| `results_10vu.json` | k6 summary output for 10 virtual users. |
| `results_50vu.json` | k6 summary output for 50 virtual users. |
| `results_100vu.json` | k6 summary output for 100 virtual users. |
| `latency_results.csv` / `.xlsx` | Combined per-endpoint, per-load-level metrics with SLA flags. |
| `latency_paper_table.csv` | Pivot of percentiles (p50, p95, p99) for the paper table. |
| `figure_p95_by_load.png` | Bar chart of p95 latency vs. load level per endpoint. |
| `process_metrics.py` | Helper script that combines the three JSON outputs into the CSV/XLSX. |

## Endpoints measured

| Internal endpoint (real) | Paper alias |
|--------------------------|-------------|
| `POST /login/` | `POST /login/` |
| `POST /ml/recomendar-tipo-ruta` | `POST /rutas/generar` |
| `GET /reminders/listar` | `GET /recordatorios` |
| `WS /ws/{group_id}` (connect) | `WS /grupo/{id} — connect` |
| `WS /ws/{group_id}` (first message) | `WS /grupo/{id} — first msg` |

The `nota_endpoints` field in each `results_*.json` documents this mapping.

## Load levels and ramp profile

Each load level uses a ramping-vus profile with three stages simulating geographic-region waves. See `load_test_k6.js::getStages()` for exact ramp curves.

| Level | Final concurrent VUs |
|-------|---------------------|
| 10 VUs | 10 |
| 50 VUs | 50 |
| 100 VUs | 100 |

## Configured SLA thresholds (k6 `options.thresholds`)

| Metric | Threshold |
|--------|-----------|
| `login_duration_ms` p95 | < 60,000 ms (permissive due to cold start) |
| `rutas_generar_duration_ms` p95 / p99 | < 5,000 / 10,000 ms |
| `reminders_duration_ms` p95 / p99 | < 3,000 / 6,000 ms |
| `ws_connect_duration_ms` p95 | < 5,000 ms |
| `ws_first_message_duration_ms` p95 | < 8,000 ms |
| `error_rate` | < 5% |

## ⚠ Critical context for interpreting these results — read before using

The backend was deployed on **Render free tier** during this measurement campaign. This deployment has documented characteristics that materially affect latency measurements:

1. **Cold-start latency:** services on the free tier are spun down after periods of inactivity and take 30–60 seconds to respond on the first request after a cold period.

2. **Shared resource limits:** CPU and memory are shared with other tenants on the same physical host; performance is non-deterministic and depends on neighbor load.

3. **Concurrent connection caps:** the free tier limits concurrent connections per service.

4. **No SLA from Render:** the free tier comes with no performance guarantees.

### Consequences for the data

- HTTP timeouts in the k6 script are set to 30 seconds. Requests that exceed this timeout are recorded as `30001 ms` and counted as errors. The reported `p95` and `p99` in `results_*.json` therefore reflect *censored* data once a non-trivial fraction of requests exceed 30 s.
- At 50 VUs, three of five endpoint metrics show `p95 = 30001 ms` (i.e., ≥ 5% of requests timed out).
- At 100 VUs, the p50 of three HTTP endpoints is ≥ 29,955 ms — meaning the majority of requests did not complete.
- Error rate rises from 14.9% (10 VUs) to 55.0% (50 VUs) to 81.3% (100 VUs).

### What these data DO support

- A descriptive characterization of system behavior **on the free tier**, useful as a transparent baseline for authors deploying on similar infrastructure.
- Verification that the application's instrumentation, k6 scripts, and percentile reporting work end-to-end.
- A documented argument that production deployment requires provisioned infrastructure.

### What these data DO NOT support

- Any claim about the architectural scalability of the system itself.
- Comparison with applications running on provisioned cloud infrastructure.
- Real-time guarantees for the WebSocket-based collaborative tracking module.

The paper (Section 5.4.2 and 6.4) reports this honestly. We include the data here for full transparency rather than omit them.

## Reproducing the latency tests on a different deployment

```bash
# Install k6
brew install k6  # or platform equivalent

# Edit load_test_k6.js:
#  - Set BASE_URL and WS_BASE_URL to your deployment
#  - Set NIVEL_CARGA to 10, 50, or 100
#  - Verify endpoint paths match your routing

k6 run load_test_k6.js
# Output is summarized to stdout and saved to resultados_<NVUS>vu.json
```

Migrating the backend to a provisioned tier (e.g., Render Standard, AWS ECS, GCP Cloud Run with min-instance > 0) is expected to produce qualitatively different results. We did not perform that comparison in this study.
