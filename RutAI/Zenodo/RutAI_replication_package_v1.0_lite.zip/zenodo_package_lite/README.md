# RutAI — Replication package

**Companion dataset for:**
Reyes Palacios L. A., Guerrero-Ulloa G. C. *Geofence-based Urban Mobility in Latin American Cities: An Empirical Evaluation of RutAI, an Integrated Mobile Application with Reinforcement Learning Route Recommendation.* Submitted to *Pervasive and Mobile Computing* (Elsevier), 2026.

**Affiliation:** Facultad de Ciencias de la Computación, Universidad Técnica Estatal de Quevedo (UTEQ), Quevedo, Los Ríos, Ecuador.

**Corresponding author:** Gleiston Cicerón Guerrero-Ulloa, PhD — gguerrero@uteq.edu.ec

---

## What is in this package

This Zenodo deposit contains all raw data, derived datasets, analysis scripts, and figures necessary to reproduce the empirical results reported in the paper. The package is organized into five thematic folders, one for each empirical component, plus supplementary material.

```
01_geofencing/        — Geofence accuracy experiment (paper §5.1) — central contribution
02_bandit_benchmark/  — Route-type recommendation benchmark (paper §5.2)
03_tam_pilot/         — TAM acceptance pilot, n=25 (paper §5.3)
04_battery/           — Battery characterization across 5 devices (paper §5.4.1)
05_latency/           — Backend latency under load (paper §5.4.2)
06_supplementary/     — Master README and metadata
```

Each folder contains its own `CODEBOOK.md` with variable-level documentation, reproducibility instructions, and—where applicable—a transparent statement of known data-quality limitations.

## Reproduction quick start

### Geofence metrics (Table 1 in the paper)

```bash
cd 01_geofencing
python calculate_geofence_metrics.py
```

Or directly from the collapsed dataset:

```python
import pandas as pd, numpy as np
df = pd.read_csv("01_geofencing/geofence_triggers_collapsed_n78.csv")
# See 01_geofencing/CODEBOOK.md for full reproduction script
```

### Bandit benchmark (Table 2 in the paper)

```bash
cd 02_bandit_benchmark
pip install -r requirements.txt
jupyter notebook bandit_simulation_reproducible.ipynb
# Run all cells; results are deterministic from base seed = 42
```

### TAM descriptive statistics (Table 3 in the paper)

```bash
cd 03_tam_pilot
python -c "
import pandas as pd
df = pd.read_csv('tam_participants_anonymized.csv', encoding='utf-8-sig')
# See 03_tam_pilot/CODEBOOK.md for full analysis
"
```

## Honest disclosure of data limitations

We follow the paper's commitment to transparency. The following limitations are documented per-folder in the corresponding `CODEBOOK.md` and are restated here for users who consult the package without reading the paper:

| Component | Limitation summary |
|-----------|-------------------|
| Geofencing | Single experimenter, single city (Quevedo), 9 rows with distance-field discrepancies (resolved by haversine recomputation), ground-truth labeling not independently certified. |
| Bandit benchmark | Synthetic Bernoulli rewards; LinUCB context is not correlated with reward by design. Stationary regime only — non-stationary evaluation is future work. |
| TAM pilot | n = 25 (below threshold for confirmatory PLS-SEM); discriminant validity between ATU/ITU/PS not achieved; 44% of participants showed straight-lining behavior. **Reported as exploratory complementary evidence, not confirmatory.** |
| Battery | 2 sessions show physically inconsistent App>Total drain (artifacts of Battery Historian parsing); 3 of 5 devices were under uncontrolled real-use conditions. Supports qualitative pattern only. |
| Latency | Backend deployed on Render free tier; cold-start and shared-resource effects censor percentiles at the 30-second timeout. **Does not support scalability claims.** |

We argue (paper §6.4) that publishing these honestly—rather than hiding them—is itself a methodological contribution to the literature on real-world mobile-system evaluation.

## License

- **Data files** (`*.csv`, `*.xlsx`, `*.json`, `*.gpx`, `*.zip`) are released under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- **Code files** (`*.py`, `*.js`, `*.ipynb`) are released under the [MIT License](https://opensource.org/licenses/MIT).

Researchers reusing these data should cite the paper (above) and this dataset:

```
Reyes Palacios L. A., Guerrero-Ulloa G. C. (2026). RutAI replication package
[Data set]. Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX
```

## Ethics

The TAM pilot was conducted with informed consent. Participants signed paper consent forms (stored separately by the host institution) before each session. Data are anonymized using opaque identifiers (U01–U25) with no link table preserved. The protocol was approved by the host faculty's review.

## Contact

For questions about this dataset, contact the corresponding author. Issues with reproducibility (script errors, missing files, unclear documentation) should be reported via the Zenodo entry's discussion tab.

## Version history

| Version | Date | Notes |
|---------|------|-------|
| 1.0 | 2026-05 | Initial deposit accompanying first manuscript submission. |
