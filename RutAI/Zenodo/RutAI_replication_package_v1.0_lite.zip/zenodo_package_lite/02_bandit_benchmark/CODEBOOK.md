# Bandit benchmark — Codebook

This folder contains the simulation results for the route-type recommendation benchmark reported in Section 5.2 of the paper.

## Files

| File | Description |
|------|-------------|
| `bandit_simulation_reproducible.ipynb` | Main reproducibility artifact. Re-runs all simulations from seeds. |
| `bandit_results.json` | Aggregated results (final regret, CIs, reward rates) per policy. |
| `bandit_regret_timesteps.csv` | Regret curves at every timestep for all policies. |
| `bandit_experiment_metadata.json` | Experimental configuration (seeds, horizon, reward probabilities, etc.). |
| `requirements.txt` | Python dependencies (numpy, scipy, matplotlib, nbformat). |
| `figure_regret_curves.png` | Cumulative regret curves with 95% bootstrap CI bands. |
| `figure_final_regret_bars.png` | Final regret bar chart with 95% CIs. |
| `figure_optimal_arm_convergence.png` | Probability of selecting the optimal arm over time. |

## Reproducibility

```bash
pip install -r requirements.txt
jupyter notebook bandit_simulation_reproducible.ipynb
```

Run all cells in order. Random seeds are fixed (base seed = 42, 100 independent runs); results are deterministic.

## Configuration

| Parameter | Value |
|-----------|-------|
| Number of arms | 3 (`fastest`, `shortest`, `recommended`) |
| Reward probabilities | (0.40, 0.50, 0.65) — Bernoulli per arm |
| Optimal arm | `recommended` (p* = 0.65) |
| Horizon (T) | 500 interactions per seed |
| Number of seeds | 100 (independent simulations) |
| Confidence interval method | Bootstrap 95% (1000 resamples on seed dimension) |
| Reward rate window | Last 100 iterations of the same simulation trace |

## Policies benchmarked

1. **Random** — uniformly random arm at each step.
2. **Greedy** — one observation per arm, then pure exploitation of empirical mean.
3. **ε-greedy (ε=0.1)** — Greedy with 10% random exploration.
4. **ε-greedy (ε=0.2)** — Greedy with 20% random exploration.
5. **Thompson Sampling** — Bernoulli–Beta with Beta(1, 1) priors. **Production policy.**
6. **LinUCB** — contextual UCB with synthetic context (hour-of-day, weekday flag, distance), reproducible from seed.
7. **UCB1 + Entropy (λ=0.1)** — UCB1 score plus λ·H(p̂) where H is binary entropy of estimated mean reward. *Initially explored, deprecated based on these results.*

## Headline result (Table 2 in the paper)

| Policy | Final regret μ | 95% CI |
|--------|---------------|--------|
| Thompson Sampling | **13.41** | [11.61, 15.38] |
| ε-greedy (0.1) | 16.58 | [13.27, 20.50] |
| ε-greedy (0.2) | 19.91 | [17.94, 22.45] |
| UCB1 + entropy | 32.82 | [31.54, 34.07] |
| LinUCB | 40.32 | [38.51, 42.01] |
| Greedy | 40.75 | [30.29, 51.28] |
| Random | 66.65 | [66.20, 67.15] |

Confidence intervals between Thompson Sampling and ε-greedy(0.1) overlap; all other policies have non-overlapping CIs against Thompson Sampling.

## Note on the entropy-regularized UCB variant

We initially considered UCB1 + λ·H(p̂) as a candidate production policy, motivated by the intuition that the entropy term would encourage exploration of arms with reward estimates near 0.5. The benchmark shows this policy underperforms simpler alternatives by a wide margin in stationary settings. The added entropy term keeps the algorithm from committing to the optimal arm even after sufficient evidence has accumulated. This is reported transparently in the paper (Section 5.2) as a negative result.

The variant may still be valuable in non-stationary environments where reward distributions drift. We leave a non-stationary benchmark to future work.

## Variables in `bandit_regret_timesteps.csv`

| Column | Type | Description |
|--------|------|-------------|
| `timestep` | int | Interaction number, 1–500 |
| `algorithm` | str | Policy name |
| `regret_mean` | float | Mean cumulative regret across 100 seeds at this timestep |
| `ci_lower` | float | Bootstrap 95% lower bound |
| `ci_upper` | float | Bootstrap 95% upper bound |
