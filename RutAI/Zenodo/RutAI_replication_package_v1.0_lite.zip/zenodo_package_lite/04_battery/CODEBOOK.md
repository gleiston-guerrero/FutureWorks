# Battery characterization — Codebook

This folder contains battery consumption data from the deployment characterization reported in Section 5.4.1 of the paper.

## Files

| File | Description |
|------|-------------|
| `battery_report.csv` / `.xlsx` | Per-session summary extracted from Battery Historian for 15 sessions (5 devices × 3 modes). |
| `battery_sessions_log.xlsx` | Session logbook with start/end times, environment notes, and device metadata. |
| `bugreports/` | Original Android bugreport ZIP files (one per session). Each ZIP can be opened with Battery Historian (https://github.com/google/battery-historian) for full per-event analysis. |

## Experimental design

- **Devices (n = 5)** spanning Android SDK 31–36:
  - D01: Samsung Galaxy A34 (5000 mAh, SDK 31)
  - D02: Honor X7b (3500 mAh, SDK 34)
  - D03: Honor Magic6 (5800 mAh, SDK 35)
  - D04: Samsung Galaxy A33 (4860–5035 mAh declared, SDK 36)
  - D05: Honor X7b (5330 mAh declared, SDK 34)

- **Modes (3 per device):**
  - `continuous` — high-priority GPS, foreground service active
  - `passive` — Fused Location Provider, low-priority
  - `off` — no location tracking

- **Session length:** ~120 minutes nominal per session

## Variables in `battery_report.csv`

The CSV is wide; key columns include:

| Column | Description |
|--------|-------------|
| `Dispositivo` | Device ID and model |
| `Modo` | Tracking mode |
| `Android_SDK` | Android API level |
| `Capacidad (mAh)` | Battery capacity declared by Battery Historian |
| `Tiempo en batería` | Total time on battery during the session |
| `Tiempo pantalla apagada` | Time with screen off |
| `Batería inicio (%)` / `Batería fin (%)` | Initial / final battery state of charge |
| `Caída batería (%)` | Battery percentage drop |
| `Computed drain (mAh)` | Total computed device drain |
| `Drain CPU (mAh)` | Drain attributed to CPU |
| `Drain sensors (mAh)` | Drain attributed to sensors (GPS) |
| `Drain mobile radio (mAh)` | Drain from cellular radio |
| `Drain WiFi (mAh)` | Drain from WiFi |
| `App total (mAh)` | Total drain attributed to RutAI's UID |
| `Warnings` | Battery Historian warnings and parse-quality notes |

## Known data-quality issues — read before using this dataset

We report these openly in the paper (Section 5.4.1) and document them here so secondary users do not draw incorrect conclusions from the raw numbers:

### Issue 1: Two sessions show physically inconsistent App-vs-total drain

| Device | Mode | Computed drain | App total | Issue |
|--------|------|---------------|-----------|-------|
| D02 Honor X7b | passive | 306 mAh | **2024 mAh** | App > total (impossible) |
| D02 Honor X7b | off | 71 mAh | **777 mAh** | App > total (impossible) |

These rows are artifacts of Battery Historian per-UID estimation when the `LEVEL` field could not be cleanly extracted. The CSV `Warnings` column annotates this. **Do not use these two rows for quantitative analysis.**

### Issue 2: Capacity inconsistency for D04 and D05

| Device | Capacities reported across sessions |
|--------|-------------------------------------|
| D04 Samsung Galaxy A33 | 5035 mAh / 4860 mAh |
| D05 Honor X7b | 3500 mAh / 6000 mAh |

The same physical device should report a constant battery capacity. These differences indicate inconsistent extraction from Battery Historian and should be treated as untrusted; the actual capacity should be looked up from the manufacturer specification.

### Issue 3: Three of five devices were under uncontrolled real-use conditions

Per `battery_sessions_log.xlsx`:
- D01: "Entorno controlado" (controlled)
- D02: "Entorno controlado" (controlled)
- D03: "Usuario uso el celular, no controlado" (real-use)
- D04: "Usuario uso el celular, no controlado, batería defectuosa" (real-use, defective battery)
- D05: "Usuario uso el celular, no controlado" (real-use)

For sessions D03–D05, the measured drain mixes RutAI's consumption with the user's other application activity. These are **not** controlled energy measurements.

### Issue 4: Five sessions did not start at 100% battery

D03 and D05 sessions started below 80% in some modes. The battery discharge curve is non-linear (especially below 30%); comparing percentage drops across sessions with different starting SoC is methodologically incorrect without normalization.

### Issue 5: Single dataset point with extreme ratio

D04 in `off` mode reports `Computed drain = 0.054 mAh` but `Drain mobile radio = 53.5 mAh` — a ratio of 991×. This is mathematically impossible and indicates corrupted parsing for that session.

## Recommended use of this dataset

1. **For qualitative confirmation of mode hierarchy** (continuous > passive > off): the controlled D01 sessions, and the controlled D02-continuous session, are reliable. They support the qualitative pattern.

2. **For quantitative claims:** this dataset does NOT support quantitative scalability or generalization claims. A more controlled energy evaluation with n ≥ 45 sessions in identical conditions remains future work.

3. **For Battery Historian replication:** the `bugreports/` folder contains the original ZIP files, which can be replayed independently in Battery Historian (https://github.com/google/battery-historian) to verify any specific extraction.

## Note for the lite version

This is the LITE version of the replication package. The original Battery Historian bugreport ZIPs (~285 MB) have been omitted for download convenience. The full version with bugreports is available as a separate Zenodo deposit/version.
