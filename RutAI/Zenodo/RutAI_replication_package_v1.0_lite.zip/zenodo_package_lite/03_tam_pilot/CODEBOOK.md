# TAM pilot — Codebook

This folder contains the anonymized response dataset from the Technology Acceptance Model pilot reported in Section 5.3 of the paper.

## Files

| File | Description |
|------|-------------|
| `tam_participants_anonymized.csv` | Per-participant responses (n = 25). Each row is one participant with all 25 Likert items. |

## Variables

### Demographic columns

| Column | Type | Values |
|--------|------|--------|
| `usuario_id` | str | U01–U25 (anonymized identifier) |
| `edad_rango` | str | "18-25", "26-35", "36-45", "46-55" |
| `genero` | str | "M", "F" |
| `ocupacion` | str | "Estudiante", "Empleado/a", "Independiente" |
| `freq_desplazamientos` | str | "Diariamente", "3-5 veces", "1-2 veces" (per week) |
| `freq_uso_apps` | str | "Diariamente", "Varias veces", "Ocasionalmente" |

### Likert item columns (5-point scale: 1 = strongly disagree, 5 = strongly agree)

| Construct | Items |
|-----------|-------|
| Perceived Usefulness (PU) | PU1–PU5 |
| Perceived Ease of Use (PEOU) | PEOU1–PEOU5 |
| Attitude Toward Use (ATU) | ATU1–ATU5 |
| Intention to Use (ITU) | ITU1–ITU5 |
| Perceived Security (PS) | PS1–PS5 |

## Sample composition (n = 25)

| Variable | Distribution |
|----------|--------------|
| Age range | 18-25: 9, 26-35: 9, 36-45: 5, 46-55: 2 |
| Gender | M: 13, F: 12 |
| Occupation | Empleado/a: 11, Estudiante: 9, Independiente: 5 |
| Mobility frequency | Diariamente: 17, 3-5 veces: 6, 1-2 veces: 2 |
| App usage frequency | Diariamente: 16, Varias veces: 6, Ocasionalmente: 3 |

## Reproducing the descriptive analysis

```python
import pandas as pd

df = pd.read_csv("tam_participants_anonymized.csv", encoding="utf-8-sig")

constructs = {
    "PU":   ["PU1","PU2","PU3","PU4","PU5"],
    "PEOU": ["PEOU1","PEOU2","PEOU3","PEOU4","PEOU5"],
    "ATU":  ["ATU1","ATU2","ATU3","ATU4","ATU5"],
    "ITU":  ["ITU1","ITU2","ITU3","ITU4","ITU5"],
    "PS":   ["PS1","PS2","PS3","PS4","PS5"],
}

# Construct scores per participant
for c, items in constructs.items():
    df[c] = df[items].mean(axis=1)

# Descriptive statistics (Table 3 in the paper)
print(df[list(constructs.keys())].agg(["mean","std","min","max","median"]).round(2).T)

# Cronbach's alpha
def cronbach(items_df):
    k = items_df.shape[1]
    item_var = items_df.var(axis=0, ddof=1).sum()
    total_var = items_df.sum(axis=1).var(ddof=1)
    return (k/(k-1)) * (1 - item_var/total_var)

for c, items in constructs.items():
    print(f"alpha_{c} = {cronbach(df[items]):.4f}")
```

Expected output matches Table 3 in the paper.

## Known limitations of this dataset

The paper reports these limitations transparently (Section 6.3); they are restated here for users of the dataset:

1. **Sample size:** n = 25 is below conventional thresholds for confirmatory PLS-SEM (n ≥ 60–100). All inferential analyses on this dataset should be treated as exploratory.

2. **Discriminant validity:** Pearson correlations between ATU, ITU, and PS exceed 0.95 in this sample. A Fornell-Larcker proxy analysis (squared correlation vs. AVE) indicates these three constructs are statistically indistinguishable. Possible causes: small sample size; over-correlated questionnaire items in this adaptation; social-desirability response patterns (see point 4).

3. **Cultural/linguistic adaptation:** the questionnaire items were adapted from Davis (1989) [40] to the urban-mobility context in Spanish for Quevedo, Ecuador. This adaptation has not been independently validated.

4. **Acquiescence bias:** 11 of 25 participants (44%) showed within-participant SD < 0.3 across all 25 items, with two participants giving identical responses on every item. This indicates substantial straight-lining, likely amplified by face-to-face administration with the experimenter present.

5. **Single time point:** participants completed the questionnaire after an initial 30–45-minute interaction with the application. Longitudinal acceptance under sustained use was not assessed.

6. **Reconciliation note:** the values in this dataset are the canonical source of truth. If discrepancies exist between summary statistics in earlier project documents and the values computed from this CSV, the CSV-derived values prevail. The paper (Section 5.3) reports CSV-derived values.
